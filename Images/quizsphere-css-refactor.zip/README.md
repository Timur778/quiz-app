# QuizSphere CSS refactor

## File layers

1. `reset.css` removes browser inconsistencies.
2. `tokens.css` stores spacing, type, radius, widths, controls, icons, and motion.
3. `themes.css` stores only theme-dependent colors and shadows.
4. `base.css` stores the shared page foundation.
5. `components.css` stores reusable topbars, cards, buttons, links, and switches.
6. `rank.css` stores rank identities.
7. Each page's own `style.css` stores only page-specific layout.

## Important fixes included

- Dark mode now changes `data-mode`, not `data-theme`.
- Selected theme and mode persist with localStorage.
- The avatar button, not only the avatar image, opens the profile menu.
- `aria-expanded`, `aria-pressed`, and the dark/light labels stay synchronized.
- The visible rank name is synchronized with `data-rank`.
- The mobile Play card correctly resets from a 2×2 span to one column.
- Customization reuses the same topbar, sizing, typography, spacing, and card system.

## Main Menu integration

Use the link order in `Main Menu/head-links.html`.

Rename:
- `style-copy.css` -> `style.css`
- `script-copy.js` -> `script.js`

Your current Main Menu HTML can otherwise remain in place. For future navigation items, use `<a class="main-menu__section navigation-card">` when they link to another page.

## Customization

A starter Customization page is included. Theme cards already change `data-theme` and save the selection. The current mode remains unchanged.
