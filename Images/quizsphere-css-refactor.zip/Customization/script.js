"use strict";

import { loadAppearance, setTheme } from "../shared/theme.js";

loadAppearance();

document.querySelectorAll("[data-theme-option]").forEach((themeCard) => {
  themeCard.addEventListener("click", () => {
    const theme = themeCard.dataset.themeOption;
    setTheme(theme);
  });
});
