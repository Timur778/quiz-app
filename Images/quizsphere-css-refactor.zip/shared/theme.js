"use strict";

const DEFAULT_THEME = "ocean";
const DEFAULT_MODE = "light";

export function loadAppearance() {
  const savedTheme = localStorage.getItem("selectedTheme") || DEFAULT_THEME;
  const savedMode = localStorage.getItem("selectedMode") || DEFAULT_MODE;

  document.documentElement.dataset.theme = savedTheme;
  document.documentElement.dataset.mode = savedMode;

  return { theme: savedTheme, mode: savedMode };
}

export function setTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem("selectedTheme", theme);
}

export function setMode(mode) {
  document.documentElement.dataset.mode = mode;
  localStorage.setItem("selectedMode", mode);
}

loadAppearance();
