"use strict";

import { loadAppearance, setMode } from "../shared/theme.js";

const soundButton = document.querySelector(".sound-button");
const soundsDropdown = document.querySelector(".sounds-dropdown");
const profileDropdown = document.querySelector(".profile-dropdown");
const avatarButton = document.querySelector(".avatar-button");

const darkModeButton = document.querySelector(".darkmode");
const darkModeLabel = document.querySelector(".darkmode-label");
const lightModeLabel = document.querySelector(".lightmode-label");
const modeToggle = document.querySelector(".toggle");

const rankingCard = document.querySelector(".dropdown-top__ranking");
const rankingName = document.querySelector(".ranking-name");

function syncModeControls(mode) {
  const isDark = mode === "dark";

  darkModeButton?.classList.toggle("active", isDark);
  modeToggle?.classList.toggle("off", isDark);
  darkModeLabel?.classList.toggle("hidden", isDark);
  lightModeLabel?.classList.toggle("hidden", !isDark);

  darkModeButton?.setAttribute("aria-pressed", String(isDark));
  darkModeButton?.setAttribute(
    "aria-label",
    isDark ? "Switch to light mode" : "Switch to dark mode",
  );
}

const appearance = loadAppearance();
syncModeControls(appearance.mode);

if (rankingCard && rankingName) {
  rankingName.textContent = rankingCard.dataset.rank || "amateur";
}

darkModeButton?.addEventListener("click", () => {
  const nextMode =
    document.documentElement.dataset.mode === "dark" ? "light" : "dark";

  setMode(nextMode);
  syncModeControls(nextMode);
});

soundButton?.addEventListener("click", (event) => {
  event.stopPropagation();
  profileDropdown?.classList.add("hidden");
  soundsDropdown?.classList.toggle("hidden");

  const expanded = !soundsDropdown?.classList.contains("hidden");
  soundButton.setAttribute("aria-expanded", String(expanded));
});

avatarButton?.addEventListener("click", (event) => {
  event.stopPropagation();
  soundsDropdown?.classList.add("hidden");
  profileDropdown?.classList.toggle("hidden");

  const expanded = !profileDropdown?.classList.contains("hidden");
  avatarButton.setAttribute("aria-expanded", String(expanded));
});

document.addEventListener("click", (event) => {
  if (
    soundsDropdown &&
    soundButton &&
    !soundsDropdown.contains(event.target) &&
    !soundButton.contains(event.target)
  ) {
    soundsDropdown.classList.add("hidden");
    soundButton.setAttribute("aria-expanded", "false");
  }

  if (
    profileDropdown &&
    avatarButton &&
    !profileDropdown.contains(event.target) &&
    !avatarButton.contains(event.target)
  ) {
    profileDropdown.classList.add("hidden");
    avatarButton.setAttribute("aria-expanded", "false");
  }
});
